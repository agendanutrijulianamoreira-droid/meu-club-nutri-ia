
import { Injectable, signal, inject, computed } from '@angular/core';
import { Challenge } from '../models/challenge.model';
import { HabitService } from './habit.service';

const getISODate = (daysOffset = 0) => {
  const date = new Date();
  date.setDate(date.getDate() + daysOffset);
  return date.toISOString().split('T')[0];
};

@Injectable({
  providedIn: 'root',
})
export class ChallengeService {
  habitService = inject(HabitService);
  
  private challengesSignal = signal<Challenge[]>([
    {
      id: 1,
      title: '30 dias intestino em paz',
      description: '**Objetivo:** Desinflamar o intestino, reduzir inchaço e...',
      type: 'VIP',
      duration: 30,
      startDate: '2025-09-22',
      endDate: '2025-10-22',
      status: 'completed',
      activities: [this.habitService.habits()[1], this.habitService.habits()[2]],
      dailyTasks: Array.from({ length: 30 }, (_, i) => ({ day: i + 1, description: `Tarefa do dia ${i + 1}`, completed: true })),
      prizeDetails: 'Premiação para os 3 melhores colocados.',
      participants: 15,
    },
    {
      id: 2,
      title: '30 dias power',
      description: 'Aumente sua energia e disposição com hábitos saudáveis.',
      type: 'Gratuito',
      duration: 30,
      startDate: '2025-10-10',
      endDate: '2025-11-09',
      status: 'completed',
      activities: [this.habitService.habits()[0], this.habitService.habits()[1]],
      dailyTasks: Array.from({ length: 30 }, (_, i) => ({ day: i + 1, description: `Tarefa do dia ${i + 1}`, completed: true })),
      prizeDetails: null,
      participants: 52,
    },
     {
      id: 3,
      title: '14 Dias Corpo em Paz',
      description: 'Um desafio para se reconectar com seu corpo e mente.',
      type: 'VIP',
      duration: 14,
      startDate: getISODate(0), // Set to start today to be "active"
      endDate: getISODate(14),
      status: 'active',
      activities: this.habitService.habits().slice(0, 4),
      dailyTasks: [
        { day: 1, description: "Beba 2L de água e registre.", completed: true },
        { day: 2, description: "Faça 30 minutos de caminhada.", completed: false },
        { day: 3, description: "Coma 3 porções de frutas hoje.", completed: false },
        { day: 4, description: "Evite telas 1h antes de dormir.", completed: false }
      ],
      prizeDetails: 'Sorteio de um kit de produtos naturais.',
      participants: 28,
    },
     {
      id: 4,
      title: 'Desafio Detox de 7 Dias',
      description: 'Uma semana para limpar o corpo e renovar as energias.',
      type: 'Gratuito',
      duration: 7,
      startDate: getISODate(20),
      endDate: getISODate(27),
      status: 'scheduled',
      activities: [this.habitService.habits()[1], this.habitService.habits()[2], this.habitService.habits()[3]],
      dailyTasks: [],
      prizeDetails: null,
      participants: 0,
    },
  ]);

  public readonly challenges = this.challengesSignal.asReadonly();
  public readonly activeChallenge = computed(() => this.challenges().find(c => c.status === 'active'));
  public readonly scheduledChallenges = computed(() => this.challenges().filter(c => c.status === 'scheduled'));


  addChallenge(challengeData: Omit<Challenge, 'id' | 'status'>) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    // Ensure dates are parsed as local time to avoid timezone bugs
    const startDate = new Date(`${challengeData.startDate}T00:00:00`);
    const endDate = new Date(`${challengeData.endDate}T00:00:00`);

    let status: 'scheduled' | 'active' | 'completed';
    if (startDate > today) {
      status = 'scheduled';
    } else if (endDate < today) {
      status = 'completed';
    } else {
      status = 'active';
    }

    const newChallenge: Challenge = {
      ...challengeData,
      id: Date.now(),
      status: status,
      participants: 0
    };
    this.challengesSignal.update(challenges => [...challenges, newChallenge]);
  }

  updateChallenge(updatedChallenge: Challenge) {
    // Recalculate status based on dates
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    // Create date objects correctly from YYYY-MM-DD string to avoid timezone issues
    const startDateParts = updatedChallenge.startDate.split('-').map(Number);
    const endDateParts = updatedChallenge.endDate.split('-').map(Number);
    const startDate = new Date(startDateParts[0], startDateParts[1] - 1, startDateParts[2]);
    const endDate = new Date(endDateParts[0], endDateParts[1] - 1, endDateParts[2]);
    
    let newStatus: 'scheduled' | 'active' | 'completed';
    if (startDate > today) {
      newStatus = 'scheduled';
    } else if (endDate < today) {
      newStatus = 'completed';
    } else {
      newStatus = 'active';
    }

    this.challengesSignal.update(challenges => 
      challenges.map(c => c.id === updatedChallenge.id ? { ...updatedChallenge, status: newStatus } : c)
    );
  }

  removeChallenge(id: number) {
    this.challengesSignal.update(challenges => challenges.filter(c => c.id !== id));
  }
}