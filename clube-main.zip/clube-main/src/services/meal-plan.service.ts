
import { Injectable, signal } from '@angular/core';
import { MealPlanProtocol } from '../models/meal-plan-protocol.model';

@Injectable({
  providedIn: 'root',
})
export class MealPlanService {
  private protocolsSignal = signal<MealPlanProtocol[]>([
    {
      id: 1,
      name: 'Protocolo Detox Pós-Festa',
      description: 'Cardápio leve para eliminar toxinas e desinchar após exageros em eventos e feriados.',
      imageUrl: 'https://picsum.photos/seed/detox/400/300',
      content: {
        breakfast: 'Suco verde (couve, abacaxi, gengibre) e 1 ovo cozido.',
        morningSnack: '1 punhado de amêndoas.',
        lunch: 'Salada de folhas verdes com frango desfiado, tomate cereja e sementes de girassol.',
        afternoonSnack: 'Chá de hibisco gelado com rodelas de laranja.',
        dinner: 'Sopa cremosa de abóbora com gengibre.'
      }
    },
    {
      id: 2,
      name: 'Cardápio Pré-Páscoa',
      description: 'Uma preparação leve e nutritiva para aproveitar o feriado de Páscoa com equilíbrio.',
      imageUrl: 'https://picsum.photos/seed/pascoa/400/300',
      content: {
        breakfast: 'Iogurte natural com frutas vermelhas e aveia.',
        morningSnack: '1 maçã com canela.',
        lunch: 'Filé de tilápia assado com purê de batata doce e brócolis.',
        afternoonSnack: 'Mix de castanhas e frutas secas.',
        dinner: 'Omelete com queijo branco, tomate e orégano.'
      }
    },
    {
        id: 3,
        name: 'Menu Romântico (Dia dos Namorados)',
        description: 'Um cardápio especial e saudável para celebrar uma data importante a dois.',
        imageUrl: 'https://picsum.photos/seed/romantico/400/300',
        content: {
          breakfast: 'Panquecas de aveia com mel e morangos.',
          morningSnack: 'Chocolate amargo 70% e um café expresso.',
          lunch: 'Risoto de cogumelos com parmesão e um fio de azeite trufado.',
          afternoonSnack: 'Taça de espumante com frutas.',
          dinner: 'Salmão ao molho de maracujá com aspargos frescos.'
        }
      },
  ]);

  public readonly protocols = this.protocolsSignal.asReadonly();

  addProtocol(protocolData: Omit<MealPlanProtocol, 'id'>) {
    const newProtocol: MealPlanProtocol = {
      ...protocolData,
      id: Date.now(),
    };
    this.protocolsSignal.update((protocols) => [...protocols, newProtocol]);
  }
  
  updateProtocol(updatedProtocol: MealPlanProtocol) {
    this.protocolsSignal.update(protocols =>
      protocols.map(p => p.id === updatedProtocol.id ? updatedProtocol : p)
    );
  }
}
