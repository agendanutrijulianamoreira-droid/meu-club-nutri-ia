
import { Injectable } from '@angular/core';
import { GoogleGenAI, Type } from '@google/genai';
import { MealPlanProtocol } from '../models/meal-plan-protocol.model';
import { DailyTask } from '../models/challenge.model';

type GeneratedProtocol = Omit<MealPlanProtocol, 'id' | 'imageUrl'>;

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private ai: GoogleGenAI | null = null;

  constructor() {
    // IMPORTANT: The API key is sourced from environment variables for security.
    // It should NOT be hardcoded in the application.
    const apiKey = process.env.API_KEY;
    if (apiKey) {
      this.ai = new GoogleGenAI({ apiKey });
    } else {
      console.error('API key for GoogleGenAI is not set. AI features will be disabled.');
    }
  }

  private async generateWithSchema<T>(contents: string, responseSchema: any): Promise<T | null> {
     if (!this.ai) {
      console.error('GoogleGenAI client is not initialized.');
      return null;
    }
    try {
       const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents,
        config: {
          responseMimeType: "application/json",
          responseSchema
        }
      });
      const jsonText = response.text.trim();
      return JSON.parse(jsonText);
    } catch(error) {
      console.error('Error generating content with Gemini:', error);
      return null;
    }
  }

  async generateProtocolIdea(theme: string): Promise<GeneratedProtocol | null> {
    return this.generateWithSchema<GeneratedProtocol>(
      `Crie um protocolo de cardápio de 1 dia com o tema: "${theme}". Gere um nome criativo para o protocolo, uma descrição curta e sugestões para café da manhã, lanche da manhã, almoço, lanche da tarde e jantar.`,
      {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: 'Nome criativo do protocolo.' },
          description: { type: Type.STRING, description: 'Descrição curta e atrativa.' },
          content: {
            type: Type.OBJECT,
            properties: {
              breakfast: { type: Type.STRING },
              morningSnack: { type: Type.STRING },
              lunch: { type: Type.STRING },
              afternoonSnack: { type: Type.STRING },
              dinner: { type: Type.STRING }
            }
          }
        }
      }
    );
  }

  async generateChallengeTasks(theme: string, duration: number, habits: string[]): Promise<DailyTask[] | null> {
    const prompt = `Crie uma lista de tarefas diárias para um desafio nutricional com o tema "${theme}" e duração de ${duration} dias. As tarefas devem ser curtas, motivacionais e baseadas nos seguintes hábitos: ${habits.join(', ')}. Gere exatamente ${duration} tarefas, uma para cada dia.`;

    const result = await this.generateWithSchema<{ tasks: { day: number, description: string }[] }>(
      prompt,
      {
        type: Type.OBJECT,
        properties: {
          tasks: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                day: { type: Type.INTEGER },
                description: { type: Type.STRING }
              }
            }
          }
        }
      }
    );

    return result ? result.tasks.map(task => ({ ...task, completed: false })) : null;
  }
}
