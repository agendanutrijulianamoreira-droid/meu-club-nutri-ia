
import { Injectable, signal } from '@angular/core';
import { Habit } from '../models/habit.model';

@Injectable({
  providedIn: 'root',
})
export class HabitService {
  private habitsSignal = signal<Habit[]>([
    {
      id: 1,
      name: 'Atividade Física',
      description: 'Mexer o corpo é liberar energia parada. Vale caminhada, alongamento, dança ou treino. O importante é sair da estagnação!',
      icon: '🏃‍♀️',
      color: 'bg-green-500',
      points: 10,
    },
    {
      id: 2,
      name: 'Beber água',
      description: 'Corpo hidratado = intestino funcionando, pele bonita e menos ansiedade. Coloque uma meta de 0,045ml a cada kg do seu peso e distribua ao longo do dia.',
      icon: '💧',
      color: 'bg-blue-500',
      points: 10,
    },
    {
      id: 3,
      name: 'Comer frutas',
      description: 'Elas são doces, naturais e cheias de micronutrientes. Escolha pelo menos 2 porções no dia. Prefira as da estação!',
      icon: '🍓',
      color: 'bg-red-500',
      points: 10,
    },
    {
      id: 4,
      name: 'Detox de redes sociais',
      description: 'Você não precisa estar online pra se sentir viva. Tire pelo menos 1h sem rolar e use esse tempo com você.',
      icon: '📵',
      color: 'bg-purple-500',
      points: 5,
    },
    {
        id: 5,
        name: 'Uma boa noite de sono',
        description: 'Durma de 7 a 8 horas por noite para regular seus hormônios e ter mais disposição.',
        icon: '😴',
        color: 'bg-indigo-500',
        points: 10,
    },
    {
        id: 6,
        name: 'Leia um livro',
        description: 'Leia algumas páginas de um livro para relaxar a mente e aprender algo novo.',
        icon: '📚',
        color: 'bg-yellow-500',
        points: 5,
    }
  ]);

  public readonly habits = this.habitsSignal.asReadonly();

  addHabit(habitData: Omit<Habit, 'id'>) {
    const newHabit: Habit = {
      ...habitData,
      id: Date.now(),
      points: 10, // Default points
    };
    this.habitsSignal.update(habits => [...habits, newHabit]);
  }

  updateHabit(updatedHabit: Habit) {
    this.habitsSignal.update(habits =>
      habits.map(h => (h.id === updatedHabit.id ? updatedHabit : h))
    );
  }

  removeHabit(id: number) {
      this.habitsSignal.update(habits => habits.filter(h => h.id !== id));
  }
}