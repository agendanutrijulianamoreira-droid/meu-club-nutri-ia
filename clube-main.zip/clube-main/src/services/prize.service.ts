
import { Injectable, signal } from '@angular/core';
import { Prize } from '../models/prize.model';

@Injectable({
  providedIn: 'root',
})
export class PrizeService {
  private prizesSignal = signal<Prize[]>([
    {
      id: 1,
      name: 'E-book de Receitas Detox',
      description: 'Um livro digital com 30 receitas para desintoxicar.',
      imageUrl: 'https://picsum.photos/seed/ebook/400/300',
    },
    {
      id: 2,
      name: 'Desconto de 20% na Consulta',
      description: 'Um cupom exclusivo para sua próxima consulta nutricional.',
      imageUrl: 'https://picsum.photos/seed/discount/400/300',
    },
    {
      id: 3,
      name: 'Playlist Exclusiva para Treinos',
      description: 'Uma seleção de músicas energéticas para motivar seus treinos.',
      imageUrl: 'https://picsum.photos/seed/playlist/400/300',
    },
  ]);

  public readonly prizes = this.prizesSignal.asReadonly();

  addPrize(prizeData: Omit<Prize, 'id'>) {
    const newPrize: Prize = {
      ...prizeData,
      id: Date.now(),
    };
    this.prizesSignal.update((prizes) => [...prizes, newPrize]);
  }

  updatePrize(updatedPrize: Prize) {
    this.prizesSignal.update(prizes => 
      prizes.map(p => p.id === updatedPrize.id ? updatedPrize : p)
    );
  }
}
