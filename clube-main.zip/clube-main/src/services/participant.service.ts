
import { Injectable, signal } from '@angular/core';
import { Participant } from '../models/participant.model';

@Injectable({
  providedIn: 'root',
})
export class ParticipantService {
  private participantsSignal = signal<Participant[]>([
    { id: 1, name: 'Ana Silva', avatarUrl: 'https://i.pravatar.cc/48?u=1', score: 1250 },
    { id: 2, name: 'Bruno Costa', avatarUrl: 'https://i.pravatar.cc/48?u=2', score: 1180 },
    { id: 3, name: 'Carla Dias', avatarUrl: 'https://i.pravatar.cc/48?u=3', score: 1150 },
    { id: 4, name: 'Daniel Alves', avatarUrl: 'https://i.pravatar.cc/48?u=4', score: 1090 },
    { id: 5, name: 'Eduarda Lima', avatarUrl: 'https://i.pravatar.cc/48?u=5', score: 1050 },
    { id: 6, name: 'Felipe Souza', avatarUrl: 'https://i.pravatar.cc/48?u=6', score: 980 },
    { id: 7, name: 'Gabriela Melo', avatarUrl: 'https://i.pravatar.cc/48?u=7', score: 950 },
    { id: 8, name: 'Henrique Faria', avatarUrl: 'https://i.pravatar.cc/48?u=8', score: 890 },
  ]);

  public readonly participants = this.participantsSignal.asReadonly();
  
  updateScore(userId: number, pointsToAdd: number) {
    this.participantsSignal.update(participants =>
      participants.map(p =>
        p.id === userId ? { ...p, score: p.score + pointsToAdd } : p
      )
    );
  }
}
