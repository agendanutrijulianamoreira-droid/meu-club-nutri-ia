
import { Component, ChangeDetectionStrategy, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChallengeService } from './services/challenge.service';
import { PrizeService } from './services/prize.service';
import { MealPlanService } from './services/meal-plan.service';
import { Challenge, EditableChallenge } from './models/challenge.model';
import { Prize } from './models/prize.model';
import { MealPlanProtocol } from './models/meal-plan-protocol.model';
import { Editable } from './models/editable.model';
import { HabitService } from './services/habit.service';
import { Habit } from './models/habit.model';

// New structural components
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { HeaderComponent } from './components/header/header.component';

// Page/Feature components
import { PrizeManagementComponent } from './components/prize-management/prize-management.component';
import { ProtocolManagementComponent } from './components/protocol-management/protocol-management.component';
import { CreatePrizeComponent } from './components/create-prize/create-prize.component';
import { CreateProtocolComponent } from './components/create-protocol/create-protocol.component';
import { ChallengeWizardComponent } from './components/challenge-wizard/challenge-wizard.component';
import { ChallengeListComponent } from './components/challenge-list/challenge-list.component';
import { HabitManagementComponent } from './components/habit-management/habit-management.component';
import { MembersAreaComponent } from './components/members-area/members-area.component';
import { CreateHabitComponent } from './components/create-habit/create-habit.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    SidebarComponent,
    HeaderComponent,
    PrizeManagementComponent,
    ProtocolManagementComponent,
    CreatePrizeComponent,
    CreateProtocolComponent,
    ChallengeWizardComponent,
    ChallengeListComponent,
    HabitManagementComponent,
    MembersAreaComponent,
    CreateHabitComponent
  ],
})
export class AppComponent {
  challengeService = inject(ChallengeService);
  prizeService = inject(PrizeService);
  mealPlanService = inject(MealPlanService);
  habitService = inject(HabitService);

  // View state
  adminPage = signal<'desafios' | 'habitos' | 'protocolos' | 'premios' | 'membros'>('desafios');

  // Modal visibility state
  showChallengeWizard = signal(false);
  showPrizeModal = signal(false);
  showProtocolModal = signal(false);
  showHabitModal = signal(false);

  // State for items being edited
  editingPrize = signal<Prize | null>(null);
  editingProtocol = signal<MealPlanProtocol | null>(null);
  editingHabit = signal<Habit | null>(null);
  editingChallenge = signal<Challenge | null>(null);

  // --- Challenge Wizard Methods ---
  openNewChallengeWizard() {
    this.editingChallenge.set(null);
    this.showChallengeWizard.set(true);
  }

  openEditChallenge(challenge: Challenge) {
    this.editingChallenge.set(challenge);
    this.showChallengeWizard.set(true);
  }
  
  closeChallengeWizard() {
     this.showChallengeWizard.set(false);
  }

  saveChallenge(challengeData: EditableChallenge) {
    if (challengeData.id) {
      this.challengeService.updateChallenge(challengeData as Challenge);
    } else {
      this.challengeService.addChallenge(challengeData as Omit<Challenge, 'id' | 'status'>);
    }
    this.closeChallengeWizard();
  }

  // --- Prize Methods ---
  openNewPrize() {
    this.editingPrize.set(null);
    this.showPrizeModal.set(true);
  }

  openEditPrize(prize: Prize) {
    this.editingPrize.set(prize);
    this.showPrizeModal.set(true);
  }

  savePrize(prizeData: Editable<Prize>) {
    if (prizeData.id) {
      this.prizeService.updatePrize(prizeData as Prize);
    } else {
      this.prizeService.addPrize(prizeData as Omit<Prize, 'id'>);
    }
    this.showPrizeModal.set(false);
  }
  
   // --- Protocol Methods ---
  openNewProtocol() {
    this.editingProtocol.set(null);
    this.showProtocolModal.set(true);
  }

  openEditProtocol(protocol: MealPlanProtocol) {
    this.editingProtocol.set(protocol);
    this.showProtocolModal.set(true);
  }

  saveProtocol(protocolData: Editable<MealPlanProtocol>) {
    if (protocolData.id) {
      this.mealPlanService.updateProtocol(protocolData as MealPlanProtocol);
    } else {
      this.mealPlanService.addProtocol(protocolData as Omit<MealPlanProtocol, 'id'>);
    }
    this.showProtocolModal.set(false);
  }

  // --- Habit Methods ---
  openNewHabit() {
    this.editingHabit.set(null);
    this.showHabitModal.set(true);
  }

  openEditHabit(habit: Habit) {
    this.editingHabit.set(habit);
    this.showHabitModal.set(true);
  }

  saveHabit(habitData: Editable<Habit>) {
     if (habitData.id) {
      this.habitService.updateHabit(habitData as Habit);
    } else {
      this.habitService.addHabit(habitData as Omit<Habit, 'id'>);
    }
    this.showHabitModal.set(false);
  }
}
