import { Component, ChangeDetectionStrategy, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MealPlanService } from '../../services/meal-plan.service';
import { MealPlanProtocol } from '../../models/meal-plan-protocol.model';

@Component({
  selector: 'app-protocol-management',
  templateUrl: './protocol-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
})
export class ProtocolManagementComponent {
  mealPlanService = inject(MealPlanService);
  protocols = this.mealPlanService.protocols;

  create = output<void>();
  edit = output<MealPlanProtocol>();
}
