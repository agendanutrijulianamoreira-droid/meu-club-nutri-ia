
import { Component, ChangeDetectionStrategy, output, signal, inject, OnInit, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Challenge, DailyTask, EditableChallenge } from '../../models/challenge.model';
import { Habit } from '../../models/habit.model';
import { HabitService } from '../../services/habit.service';
import { GeminiService } from '../../services/gemini.service';

@Component({
  selector: 'app-challenge-wizard',
  templateUrl: './challenge-wizard.component.html',
  styleUrls: ['./challenge-wizard.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
})
export class ChallengeWizardComponent implements OnInit {
  challengeToEdit = input<Challenge | null>(null);
  close = output<void>();
  save = output<EditableChallenge>();
  
  habitService = inject(HabitService);
  geminiService = inject(GeminiService);
  availableHabits = this.habitService.habits;

  currentStep = signal(1);
  isGeneratingTasks = signal(false);
  
  challengeData = signal<EditableChallenge>({
    title: '',
    description: '',
    type: 'Gratuito',
    duration: 14,
    startDate: new Date().toISOString().split('T')[0],
    endDate: this.calculateEndDate(new Date().toISOString().split('T')[0], 14),
    activities: [],
    dailyTasks: [],
    prizeDetails: null,
    participants: 0,
    status: 'scheduled'
  });

  ngOnInit() {
    const challenge = this.challengeToEdit();
    if (challenge) {
      this.challengeData.set({
        ...challenge
      });
    }
  }

  formatDate(dateString: string | undefined): string {
    if (!dateString) return '';
    const date = new Date(`${dateString}T00:00:00`);
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  }

  isHabitSelected(habit: Habit): boolean {
    return this.challengeData().activities?.some(h => h.id === habit.id) ?? false;
  }

  toggleHabitSelection(habit: Habit) {
    this.challengeData.update(data => {
      const activities = data.activities ? [...data.activities] : [];
      const index = activities.findIndex(h => h.id === habit.id);
      if (index > -1) {
        activities.splice(index, 1);
      } else {
        activities.push(habit);
      }
      return { ...data, activities };
    });
  }

  updateField(field: keyof EditableChallenge, valueOrEvent: any) {
    let value: any;
    // Check if it's an event from an input/textarea or a direct value from a click
    if (valueOrEvent instanceof Event && valueOrEvent.target) {
      value = (valueOrEvent.target as HTMLInputElement | HTMLTextAreaElement).value;
    } else {
      value = valueOrEvent;
    }
    this.challengeData.update(data => ({ ...data, [field]: value }));
  }

  updateDailyTask(index: number, event: Event) {
    const newDescription = (event.target as HTMLInputElement).value;
    this.challengeData.update(data => {
      const newTasks = [...(data.dailyTasks || [])];
      if(newTasks[index]) {
        newTasks[index] = {...newTasks[index], description: newDescription};
      }
      return {...data, dailyTasks: newTasks};
    });
  }

  async generateTasksWithAI() {
    const data = this.challengeData();
    if (!data.title || !data.duration || !data.activities || data.activities.length === 0) {
      alert('Preencha o título, duração e selecione ao menos um hábito para gerar as tarefas.');
      return;
    }
    this.isGeneratingTasks.set(true);
    const habitNames = data.activities.map(h => h.name);
    const tasks = await this.geminiService.generateChallengeTasks(data.title, data.duration, habitNames);
    if (tasks) {
      this.challengeData.update(d => ({ ...d, dailyTasks: tasks }));
    } else {
      alert('Não foi possível gerar as tarefas. Tente novamente.');
    }
    this.isGeneratingTasks.set(false);
  }

  handleDateChange(event: Event) {
    const startDate = (event.target as HTMLInputElement).value;
    const duration = this.challengeData().duration ?? 14;
    this.challengeData.update(data => ({
      ...data,
      startDate,
      endDate: this.calculateEndDate(startDate, duration)
    }));
  }

  handleDurationChange(event: Event) {
    const duration = Number((event.target as HTMLInputElement).value);
    const startDate = this.challengeData().startDate ?? new Date().toISOString().split('T')[0];
    this.challengeData.update(data => ({
      ...data,
      duration,
      endDate: this.calculateEndDate(startDate, duration)
    }));
  }

  setDuration(days: number) {
    const startDate = this.challengeData().startDate ?? new Date().toISOString().split('T')[0];
    this.challengeData.update(data => ({
      ...data,
      duration: days,
      endDate: this.calculateEndDate(startDate, days)
    }));
  }

  // FIX: Replaced brittle date calculation with a robust, timezone-safe version.
  calculateEndDate(startDate: string, duration: number): string {
    // Using `new Date(YYYY-MM-DD)` is unreliable due to timezones.
    // Appending T00:00:00 forces it to be parsed as local time midnight, making it safe.
    const date = new Date(`${startDate}T00:00:00`);
    date.setDate(date.getDate() + duration);
    return date.toISOString().split('T')[0];
  }
  
  nextStep() {
    if (this.currentStep() < 6) {
      this.currentStep.update(s => s + 1);
    }
  }

  prevStep() {
    if (this.currentStep() > 1) {
      this.currentStep.update(s => s - 1);
    }
  }

  finish() {
    // Validation
    const data = this.challengeData();
    if (!data.title || !data.startDate || !data.duration || !data.activities || data.activities.length === 0) {
      alert('Por favor, preencha todos os campos obrigatórios e selecione ao menos uma atividade.');
      return;
    }

    this.save.emit(data);
  }
}