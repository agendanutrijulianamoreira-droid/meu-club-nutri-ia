
import { Component, ChangeDetectionStrategy, output, input } from '@angular/core';
import { CommonModule } from '@angular/common';

type Page = 'desafios' | 'habitos' | 'protocolos' | 'premios' | 'membros';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
})
export class SidebarComponent {
  navigate = output<Page>();
  activePage = input.required<Page>();
  
  selectPage(page: Page) {
    this.navigate.emit(page);
  }
}
