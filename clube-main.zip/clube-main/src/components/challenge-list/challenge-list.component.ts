
import { Component, ChangeDetectionStrategy, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChallengeService } from '../../services/challenge.service';
import { Challenge } from '../../models/challenge.model';

@Component({
  selector: 'app-challenge-list',
  templateUrl: './challenge-list.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
})
export class ChallengeListComponent {
  challengeService = inject(ChallengeService);
  challenges = this.challengeService.challenges;
  
  newChallenge = output<void>();
  edit = output<Challenge>();

  formatDate(dateString: string): string {
    if (!dateString) return '';
    // This ensures the date string is parsed as local time, not UTC, preventing off-by-one day errors.
    const date = new Date(`${dateString}T00:00:00`);
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  }
}