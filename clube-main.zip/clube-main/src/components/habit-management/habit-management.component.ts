
import { Component, ChangeDetectionStrategy, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HabitService } from '../../services/habit.service';
import { Habit } from '../../models/habit.model';

@Component({
  selector: 'app-habit-management',
  templateUrl: './habit-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
})
export class HabitManagementComponent {
  habitService = inject(HabitService);
  habits = this.habitService.habits;

  create = output<void>();
  edit = output<Habit>();

  deleteHabit(id: number) {
    if (confirm('Tem certeza que deseja excluir este hábito?')) {
      this.habitService.removeHabit(id);
    }
  }
}
