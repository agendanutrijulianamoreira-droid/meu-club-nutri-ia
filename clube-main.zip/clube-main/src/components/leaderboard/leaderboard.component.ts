
import { Component, ChangeDetectionStrategy, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ParticipantService } from '../../services/participant.service';
import { Participant } from '../../models/participant.model';

@Component({
  selector: 'app-leaderboard',
  templateUrl: './leaderboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
})
export class LeaderboardComponent {
  participantService = inject(ParticipantService);
  
  rankedParticipants = computed(() => {
    // Create a new array to avoid mutating the original signal's array
    return [...this.participantService.participants()].sort((a, b) => b.score - a.score);
  });
}
