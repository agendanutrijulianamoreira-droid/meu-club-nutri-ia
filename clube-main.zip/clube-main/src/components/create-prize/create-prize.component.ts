import { Component, ChangeDetectionStrategy, output, signal, input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Prize } from '../../models/prize.model';
import { Editable } from '../../models/editable.model';

@Component({
  selector: 'app-create-prize',
  templateUrl: './create-prize.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
})
export class CreatePrizeComponent implements OnInit {
  prizeToEdit = input<Prize | null>(null);
  
  close = output<void>();
  save = output<Editable<Prize>>();

  modalTitle = signal('Adicionar Novo Prêmio');

  id = signal<number | undefined>(undefined);
  name = signal('');
  description = signal('');
  imageUrl = signal('');

  ngOnInit() {
    const prize = this.prizeToEdit();
    if (prize) {
      this.modalTitle.set('Editar Prêmio');
      this.id.set(prize.id);
      this.name.set(prize.name);
      this.description.set(prize.description);
      this.imageUrl.set(prize.imageUrl);
    }
  }

  onSave() {
    if (this.name() && this.description()) {
      this.save.emit({
        id: this.id(),
        name: this.name(),
        description: this.description(),
        imageUrl: this.imageUrl() || `https://picsum.photos/seed/${this.name()}/400/300`,
      });
    } else {
      alert('Por favor, preencha o nome e a descrição.');
    }
  }

  updateSignal(sig: any, event: Event) {
    const input = event.target as HTMLInputElement | HTMLTextAreaElement;
    sig.set(input.value);
  }
}
