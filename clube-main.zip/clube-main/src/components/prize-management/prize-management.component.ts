import { Component, ChangeDetectionStrategy, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrizeService } from '../../services/prize.service';
import { Prize } from '../../models/prize.model';

@Component({
  selector: 'app-prize-management',
  templateUrl: './prize-management.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
})
export class PrizeManagementComponent {
  prizeService = inject(PrizeService);
  prizes = this.prizeService.prizes;

  create = output<void>();
  edit = output<Prize>();
}
