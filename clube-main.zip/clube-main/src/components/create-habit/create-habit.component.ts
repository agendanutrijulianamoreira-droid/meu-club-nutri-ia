
import { Component, ChangeDetectionStrategy, output, signal, input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Habit, EditableHabit } from '../../models/habit.model';

@Component({
  selector: 'app-create-habit',
  templateUrl: './create-habit.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
})
export class CreateHabitComponent implements OnInit {
  habitToEdit = input<Habit | null>(null);
  
  close = output<void>();
  save = output<EditableHabit>();

  modalTitle = signal('Adicionar Novo Hábito');

  // Form Signals
  id = signal<number | undefined>(undefined);
  name = signal('');
  description = signal('');
  icon = signal('✨');
  color = signal('bg-green-500');

  availableColors = ['bg-green-500', 'bg-blue-500', 'bg-red-500', 'bg-purple-500', 'bg-yellow-500', 'bg-indigo-500', 'bg-pink-500', 'bg-orange-500'];

  ngOnInit() {
    const habit = this.habitToEdit();
    if (habit) {
      this.modalTitle.set('Editar Hábito');
      this.id.set(habit.id);
      this.name.set(habit.name);
      this.description.set(habit.description);
      this.icon.set(habit.icon);
      this.color.set(habit.color);
    }
  }

  onSave() {
    if (this.name() && this.description() && this.icon()) {
      this.save.emit({
        id: this.id(),
        name: this.name(),
        description: this.description(),
        icon: this.icon(),
        color: this.color(),
      });
    } else {
      alert('Por favor, preencha todos os campos.');
    }
  }

  updateSignal(sig: any, event: Event) {
    const input = event.target as HTMLInputElement | HTMLTextAreaElement;
    sig.set(input.value);
  }

  selectColor(selectedColor: string) {
    this.color.set(selectedColor);
  }
}
