
import { Component, ChangeDetectionStrategy, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChallengeService } from '../../services/challenge.service';
import { ActiveChallengeComponent } from '../active-challenge/active-challenge.component';
import { LeaderboardComponent } from '../leaderboard/leaderboard.component';
import { MealPlanService } from '../../services/meal-plan.service';

@Component({
  selector: 'app-members-area',
  templateUrl: './members-area.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ActiveChallengeComponent, LeaderboardComponent],
})
export class MembersAreaComponent {
  challengeService = inject(ChallengeService);
  mealPlanService = inject(MealPlanService);

  activeChallenge = this.challengeService.activeChallenge;
  scheduledChallenges = this.challengeService.scheduledChallenges;
  
  latestProtocol = computed(() => {
    const protocols = this.mealPlanService.protocols();
    // Return the last protocol in the array, simulating the "latest" one
    return protocols.length > 0 ? protocols[protocols.length - 1] : null;
  });

  formatDate(dateString: string): string {
    const date = new Date(`${dateString}T00:00:00`);
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
  }
}
