import { Component, ChangeDetectionStrategy, output, signal, inject, input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MealPlanProtocol } from '../../models/meal-plan-protocol.model';
import { Editable } from '../../models/editable.model';
import { GeminiService } from '../../services/gemini.service';

@Component({
  selector: 'app-create-protocol',
  templateUrl: './create-protocol.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
})
export class CreateProtocolComponent implements OnInit {
  protocolToEdit = input<MealPlanProtocol | null>(null);

  close = output<void>();
  save = output<Editable<MealPlanProtocol>>();
  
  geminiService = inject(GeminiService);

  modalTitle = signal('Adicionar Novo Protocolo');
  isGenerating = signal(false);
  
  // Form Signals
  id = signal<number | undefined>(undefined);
  name = signal('');
  description = signal('');
  imageUrl = signal('');
  breakfast = signal('');
  morningSnack = signal('');
  lunch = signal('');
  afternoonSnack = signal('');
  dinner = signal('');
  
  aiTheme = signal('');

  ngOnInit() {
    const protocol = this.protocolToEdit();
    if (protocol) {
      this.modalTitle.set('Editar Protocolo');
      this.id.set(protocol.id);
      this.name.set(protocol.name);
      this.description.set(protocol.description);
      this.imageUrl.set(protocol.imageUrl);
      this.breakfast.set(protocol.content.breakfast);
      this.morningSnack.set(protocol.content.morningSnack);
      this.lunch.set(protocol.content.lunch);
      this.afternoonSnack.set(protocol.content.afternoonSnack);
      this.dinner.set(protocol.content.dinner);
    }
  }

  async generateProtocol() {
    if (!this.aiTheme()) return;
    this.isGenerating.set(true);
    const idea = await this.geminiService.generateProtocolIdea(this.aiTheme());
    if (idea) {
      this.name.set(idea.name);
      this.description.set(idea.description);
      this.breakfast.set(idea.content.breakfast);
      this.morningSnack.set(idea.content.morningSnack);
      this.lunch.set(idea.content.lunch);
      this.afternoonSnack.set(idea.content.afternoonSnack);
      this.dinner.set(idea.content.dinner);
    }
    this.isGenerating.set(false);
  }

  onSave() {
    if (this.name() && this.breakfast() && this.lunch() && this.dinner()) {
      this.save.emit({
        id: this.id(),
        name: this.name(),
        description: this.description(),
        imageUrl: this.imageUrl() || `https://picsum.photos/seed/${this.name()}/400/300`,
        content: {
          breakfast: this.breakfast(),
          morningSnack: this.morningSnack(),
          lunch: this.lunch(),
          afternoonSnack: this.afternoonSnack(),
          dinner: this.dinner(),
        }
      });
    } else {
        alert('Por favor, preencha pelo menos nome, café da manhã, almoço e jantar.');
    }
  }

  updateSignal(sig: any, event: Event) {
    const input = event.target as HTMLInputElement | HTMLTextAreaElement;
    sig.set(input.value);
  }
}
