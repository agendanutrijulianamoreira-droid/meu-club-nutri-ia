
import { Component, ChangeDetectionStrategy, input, signal, effect, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Challenge, DailyTask } from '../../models/challenge.model';
import { ParticipantService } from '../../services/participant.service';

@Component({
  selector: 'app-active-challenge',
  templateUrl: './active-challenge.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
})
export class ActiveChallengeComponent {
  challenge = input<Challenge | undefined | null>();
  participantService = inject(ParticipantService);
  
  tasks = signal<DailyTask[]>([]);
  
  // Gamification state
  challengeScore = signal(0);
  streak = signal(0);

  // Assuming user ID 1 ('Ana Silva') is the current user for this demo
  private readonly USER_ID = 1; 
  
  constructor() {
    effect(() => {
      const currentChallenge = this.challenge();
      this.tasks.set(currentChallenge?.dailyTasks ? [...currentChallenge.dailyTasks] : []);
      this.recalculateState(); // Recalculate score and streak when tasks/challenge change
    });
  }

  completedDays = computed(() => {
    return this.tasks().filter(t => t.completed).length;
  });

  currentDay = computed(() => {
    const chal = this.challenge();
    if (!chal?.startDate) return 1;

    const startDate = new Date(`${chal.startDate}T00:00:00`);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const diffTime = Math.max(0, today.getTime() - startDate.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24)) + 1;
    
    return Math.min(diffDays, chal.duration);
  });

  progressPercent = computed(() => {
    const chal = this.challenge();
    if (!chal || chal.duration === 0) return 0;
    return Math.round((this.completedDays() / chal.duration) * 100);
  });

  private recalculateState() {
    let score = 0;
    let currentStreak = 0;
    let maxStreak = 0;
    const taskList = this.tasks();

    // This calculates the longest consecutive streak of completed tasks
    for (const task of taskList) {
      if (task.completed) {
        score += 10; // +10 points per completed task as per blueprint
        currentStreak++;
      } else {
        maxStreak = Math.max(maxStreak, currentStreak);
        currentStreak = 0; // Reset streak if a task is not completed
      }
    }
    maxStreak = Math.max(maxStreak, currentStreak);
    
    this.challengeScore.set(score);
    this.streak.set(maxStreak);
  }

  toggleTaskCompletion(taskDay: number) {
    let pointsChange = 0;
    this.tasks.update(currentTasks => 
      currentTasks.map(task => {
        if (task.day === taskDay) {
          pointsChange = task.completed ? -10 : 10;
          return { ...task, completed: !task.completed };
        }
        return task;
      })
    );
    
    // Update total score in the participant service
    this.participantService.updateScore(this.USER_ID, pointsChange);

    // Recalculate local state like streak after the update
    this.recalculateState();
  }
}