
// Utility type to make ID optional for creation forms
export type Editable<T extends { id: any }> = Omit<T, 'id'> & { id?: T['id'] };
