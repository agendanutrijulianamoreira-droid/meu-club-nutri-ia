
export interface MealPlanProtocol {
  id: number;
  name: string;
  description: string;
  // Content is structured for one representative day
  content: {
    breakfast: string;
    morningSnack: string;
    lunch: string;
    afternoonSnack: string;
    dinner: string;
  };
  imageUrl: string;
}
