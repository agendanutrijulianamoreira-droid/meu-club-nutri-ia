
import { Editable } from './editable.model';

export interface Habit {
    id: number;
    name: string;
    description: string;
    icon: string; // Emoji
    color: string; // Tailwind color class
    points: number;
}

export type EditableHabit = Editable<Habit>;