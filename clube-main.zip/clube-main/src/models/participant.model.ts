
export interface Participant {
    id: number;
    name: string;
    avatarUrl: string;
    score: number;
}
