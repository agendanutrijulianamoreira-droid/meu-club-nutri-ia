
import { Habit } from './habit.model';
import { Editable } from './editable.model';

export interface DailyTask {
  day: number;
  description: string;
  completed: boolean;
}

export interface Challenge {
  id: number;
  title: string;
  description: string;
  type: 'Gratuito' | 'VIP';
  duration: number;
  startDate: string; // ISO string format: 'YYYY-MM-DD'
  endDate: string; // ISO string format: 'YYYY-MM-DD'
  status: 'scheduled' | 'active' | 'completed';
  activities: Habit[];
  dailyTasks: DailyTask[];
  prizeDetails: string | null;
  participants: number;
}

export type EditableChallenge = Editable<Challenge>;
