
export interface Prize {
  id: number;
  name: string;
  description: string;
  imageUrl: string;
}
